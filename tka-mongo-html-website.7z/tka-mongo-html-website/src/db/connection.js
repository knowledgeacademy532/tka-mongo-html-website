const mongoose=require("mongoose");
//creating a datatbase
mongoose.set('strictQuery',true);
mongoose.connect("mongodb://127.0.0.1:27017/tka-mongo-db",
	{useNewUrlParser: true,
	useNewUrlParser:true,
	useUnifiedTopology:true
	}
    
	
).then(()=>{
	console.log("connection successfull");
}).catch((error)=>{
console.log(error);
});
